﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace computer_shop_login_page
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void btn_logout_Click(object sender, EventArgs e)
        {
            Admin admin = new Admin();
            admin.Show();
            this.Close();
        }

        private void btn_menu_Click(object sender, EventArgs e)
        {
            Items items = new Items();
            items.Show();
            this.Close();
        }

        private void btn_dashboard_Click(object sender, EventArgs e)
        {
            Customer customer = new Customer();
            customer.Show();
            this.Close();
        }

      

        private void Btn_Customer_Click_1(object sender, EventArgs e)
        {
            Customer customer = new Customer();
            customer.Show();
            //this.Close();
        }

        private void btn_menu_Click_1(object sender, EventArgs e)
        {
            Items items = new Items();
            items.Show();
            this.Close();
        }

        SqlConnection Con = new SqlConnection(@"Data Source=LAPTOP-IQDRMD3\SQLEXPRESS;Initial Catalog=Computer_shopDB;Integrated Security=True");

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you went to log out", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                Admin admin = new Admin();
                admin.Show();
                this.Close();
            }
        }

        private void btnCus_details_Click(object sender, EventArgs e)
        {
            Customer customer1 = new Customer();
            customer1.Show();
            this.Hide();
        }

        private void btn_Items_Click(object sender, EventArgs e)
        {
            Items items = new Items();
            items.Show();
            this.Hide();
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
           
        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {
            
        }
    }
}


        

