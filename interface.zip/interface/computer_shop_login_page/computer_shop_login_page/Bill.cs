﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace computer_shop_login_page
{
    public partial class Bill : Form
    {
        public Bill()
        {
            InitializeComponent();
        }
        private const string Item_Name = "Items";
        SqlConnection Con = new SqlConnection(@"Data Source=LAPTOP-IQDRMD3\SQLEXPRESS;Initial Catalog=Computer_shopDB;Integrated Security=True");
        private void Populate()
        {
            Con.Open();
            string query = "select * from Bill";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            dataGridView2.DataSource = ds.Tables[0];
            Con.Close();
        }

        private void btnbill_Click(object sender, EventArgs e)
        {
            if ( txtID.Text == ""||txtName.Text == "" || txtPrice.Text == "" || txtQuen.Text == "" )
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    using (SqlConnection Con = new SqlConnection(@"Data Source=LAPTOP-IQDRMD3\SQLEXPRESS;Initial Catalog=Computer_shopDB;Integrated Security=True"))
                    {
                        Con.Open();



                        string query = "INSERT INTO Bill VALUES (@ID, @Name, @Quantity, @Price)";

                        using (SqlCommand cmd = new SqlCommand(query, Con))
                        {

                            cmd.Parameters.AddWithValue("@Name", txtName.Text);
                            cmd.Parameters.AddWithValue("@Quantity", txtQuen.Text);
                            cmd.Parameters.AddWithValue("@Price", txtPrice.Text);

                            cmd.ExecuteNonQuery();
                        }

                        MessageBox.Show("Items Saved Successfully");
                        Populate();
                        Reset();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }


            }    
        }

        private void Reset()
        {
            throw new NotImplementedException();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            
        }
    }
}
   
    

