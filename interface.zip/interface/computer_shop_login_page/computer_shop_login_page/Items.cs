﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace computer_shop_login_page
{
    public partial class Items : Form
    {

        public Items()
        {
            InitializeComponent();
            Populate();
        }
        private const string Item_Name = "Item_Name";
        SqlConnection Con = new SqlConnection(@"Data Source=LAPTOP-IQDRMD3\SQLEXPRESS;Initial Catalog=Computer_shopDB;Integrated Security=True");
        private void Populate()
        {
            Con.Open();
            string query = "select * from ItemTable";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            Con.Close();
        }
        private void Filter()
        {
            Con.Open();
            string query = "select * from ItemTable where Item_Category='" + comboBox2.SelectedItem.ToString() + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            Con.Close();

        }

        private void Btn_Customer_Click(object sender, EventArgs e)
        {
            Customer customer = new Customer();
            customer.Show();
            this.Hide();
        }

        private void btn_dashboard_Click(object sender, EventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Show();
            this.Hide();
        }



        private void btn_logout_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you went to log out", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                Admin admin = new Admin();
                admin.Show();
                this.Close();
            }

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "" || txtQuentity.Text == "" || ItemcomboBox.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    using (SqlConnection Con = new SqlConnection(@"Data Source=LAPTOP-IQDRMD3\SQLEXPRESS;Initial Catalog=Computer_shopDB;Integrated Security=True"))
                    {
                        Con.Open();

                        // Assuming ItemcomboBox is a ComboBox containing items with text values
                        string selectedItemText = ItemcomboBox.SelectedItem.ToString();

                        string query = "INSERT INTO ItemTable VALUES (@No, @Name, @SelectedItem, @Quantity, @Price)";

                        using (SqlCommand cmd = new SqlCommand(query, Con))
                        {
                            cmd.Parameters.AddWithValue("@No", txtNo.Text);
                            cmd.Parameters.AddWithValue("@Name", txtName.Text);
                            cmd.Parameters.AddWithValue("@SelectedItem", selectedItemText);
                            cmd.Parameters.AddWithValue("@Quantity", txtQuentity.Text);
                            cmd.Parameters.AddWithValue("@Price", txtPrice.Text);

                            cmd.ExecuteNonQuery();
                        }

                        MessageBox.Show("Items Saved Successfully");
                        Populate();
                        Reset();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }

        }

        private void txtedit_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "" || txtQuentity.Text == "" || ItemcomboBox.SelectedIndex == -1)
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "UPDATE ItemTable SET Item_Name='" + txtName.Text + "', " +
                                   "Item_Category='" + ItemcomboBox.SelectedItem.ToString() + "', " +
                                   "Quentity='" + txtQuentity.Text + "', " +
                                   "Price='" + txtPrice.Text + "' " +
                                   "WHERE Item_No='" + txtNo.Text + "'";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Item Updated Successfully");
                    Con.Close();
                    Populate();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }


        private void populate()
        {
            throw new NotImplementedException();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                String Skey = ((String)dataGridView1.SelectedRows[0].Cells[0].Value).Trim();

                try
                {
                    Con.Open();
                    string query = "delete from ItemTable where Item_No=" + Skey.Trim() + "; ";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Item Deleted Successfully");
                    Con.Close();
                    Populate();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }


            }
            else
            {
                MessageBox.Show("Select only a single record to delete at a time");
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            Reset();
        }
        int key = 0;

        public object Skey { get; private set; }

        private void btnrefresh_Click(object sender, EventArgs e)
        {
            Populate();
            comboBox2.SelectedIndex = -1;
        }
        private void Reset()
        {
            txtNo.Text = "";
            txtName.Text = "";
            comboBox2.SelectedIndex = -1;
            txtPrice.Text = "";
            txtQuentity.Text = "";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Items_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'computer_shopDBDataSet1.ItemTable' table. You can move, or remove it, as needed.
            //itemTableTableAdapter.Fill(this.computer_shopDBDataSet1.ItemTable);

        }
        
        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                String Skey = ((String)dataGridView1.SelectedRows[0].Cells[0].Value).Trim();

                try
                {
                    Con.Open();
                    string query = "delete from ItemTable where Item_No=" + Skey.Trim() + "; ";
                    SqlCommand cmd = new SqlCommand(query, Con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Item Deleted Successfully");
                    Con.Close();
                    Populate();
                    Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }


            }
            else
            {
                MessageBox.Show("Select only a single record to delete at a time");
            }

        }

        private void btnReset_Click_1(object sender, EventArgs e)
        {
            Reset();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Filter();
        }
    }
}
    
