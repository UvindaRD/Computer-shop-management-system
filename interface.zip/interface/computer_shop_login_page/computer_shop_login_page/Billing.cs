﻿using System;

namespace computer_shop_login_page
{
    internal class Billing
    {
        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}