﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

using System.Configuration;
using System.Data;

namespace computer_shop_login_page
{
    internal class ConnectionManager
    {
        public static SqlConnection newta;
        public static string constr = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;


        public static SqlConnection GetConnection()
        {
            newta = new SqlConnection(constr);
            return newta;
        }

    }
}
