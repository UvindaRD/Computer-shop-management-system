﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace computer_shop_login_page
{
    public partial class Customer : Form
    {



        public Customer()
        {
            InitializeComponent();
            Populate();
        }
        private const string Cus_name = "Cus_name";
        SqlConnection Con = new SqlConnection(@"Data Source=LAPTOP-IQDRMD3\SQLEXPRESS;Initial Catalog=Computer_shopDB;Integrated Security=True");
        private void Populate()
        {
            Con.Open();
            string query = "select * from Customers_Table";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            DataTable datatable = new DataTable();
            sda.Fill(datatable);
            cus_data.DataSource = datatable;
            Con.Close();


        }


        private void Reset()
        {
            
            txt_cusName.Text = "";
            PhoneNumberTextBox.Text = "";
            txt_Address.Text = "";
            txt_Password.Text = "";
            txtCusID.Text = "";
        }


        int key = 0;



        private void btn_Add_Click(object sender, EventArgs e)
        {
            if (txt_cusName.Text == "" || PhoneNumberTextBox.Text == "" || txt_Address.Text == "" || txt_Password.Text == "")
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    Con.Open();
                    string query = "INSERT INTO Customers_Table VALUES (@CusID, @CusName, @UserPhoneNumber, @UserAddress, @UserPassword)";
                    SqlCommand cmd = new SqlCommand(query, Con);

                    // Use parameters to avoid SQL injection
                    cmd.Parameters.AddWithValue("@CusID", txtCusID.Text);
                    cmd.Parameters.AddWithValue("@CusName", txt_cusName.Text);
                    cmd.Parameters.AddWithValue("@UserPhoneNumber", PhoneNumberTextBox.Text);
                    cmd.Parameters.AddWithValue("@UserAddress", txt_Address.Text);
                    cmd.Parameters.AddWithValue("@UserPassword", txt_Password.Text);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Customer details Saved Successfully");
                    Con.Close();
                    Populate();
                    // Reset();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void Clear()
        {
            txt_cusName.Text = "";
            PhoneNumberTextBox.Text = "";
            txt_Address.Text = "";
            txt_Password.Text = "";
        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_cusName.Text) || string.IsNullOrEmpty(PhoneNumberTextBox.Text) || string.IsNullOrEmpty(txt_Address.Text) || string.IsNullOrEmpty(txt_Password.Text))
            {
                MessageBox.Show("Missing Information");
            }
            else
            {
                try
                {
                    using (SqlConnection Con = new SqlConnection(@"Data Source=LAPTOP-IQDRMD3\SQLEXPRESS;Initial Catalog=Computer_shopDB;Integrated Security=True"))
                    {
                        Con.Open();
                        string query = "UPDATE Customers_Table SET Cus_Name=@CusName, Phone_Number=@UserPhoneNumber, Address=@UserAddress, Password=@UserPassword WHERE Cus_ID=@CusID";
                        using (SqlCommand cmd = new SqlCommand(query, Con))
                        {
                            cmd.Parameters.AddWithValue("@CusName", txt_cusName.Text);
                            cmd.Parameters.AddWithValue("@UserPhoneNumber", PhoneNumberTextBox.Text);
                            cmd.Parameters.AddWithValue("@UserAddress", txt_Address.Text);
                            cmd.Parameters.AddWithValue("@UserPassword", txt_Password.Text);
                            cmd.Parameters.AddWithValue("@CusID", txtCusID.Text);

                            // Execute the query
                            cmd.ExecuteNonQuery();
                        }
                    }

                    Populate();
                    Reset();
                    MessageBox.Show("Customer information updated successfully");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error updating customer information: " + ex.Message);
                }
            }

        }

        private void populate()
        {
            throw new NotImplementedException();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection Con = new SqlConnection(@"Data Source=LAPTOP-IQDRMD3\SQLEXPRESS;Initial Catalog=Computer_shopDB;Integrated Security=True"))
                {
                    Con.Open();

                    string query = "DELETE FROM Customers_Table WHERE Cus_ID=@CusID";

                    using (SqlCommand cmd = new SqlCommand(query, Con))
                    {
                        cmd.Parameters.AddWithValue("@CusID", txtCusID.Text);

                        // Output the SQL query for debugging
                        Console.WriteLine("Executing SQL query: " + cmd.CommandText);

                        // Execute the query
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Customer Deleted Successfully");
                            Populate();
                            Reset();
                        }
                        else
                        {
                            MessageBox.Show("No customer found with the specified Cus_ID.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting customer: " + ex.ToString());
            }


        }



        private void Customer_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'computer_shopDBDataSet.UserTable' table. You can move, or remove it, as needed.
            //userTableTableAdapter.Fill(this.computer_shopDBDataSet.UserTable);

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("Are you went to log out", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dialogResult == DialogResult.Yes)
            {
                Admin admin = new Admin();
                admin.Show();
                this.Close();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Items items = new Items();
            items.Show();
            this.Close();
        }

       


    }
}
























