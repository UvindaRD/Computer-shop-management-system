﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace computer_shop_login_page.common
{
    internal class DBConnection
    {
        private SqlConnection connection;
        private SqlCommand command;
        private SqlDataAdapter dataAdaptor;
        //Data Retrieval
        private SqlCommandBuilder commandBuilder;
        private String connectionString = @"Data Source=LAPTOP-IQDRMD3\SQLEXPRESS;Initial Catalog=ComputerinventoryTB;Integrated Security=True";

        //Constructor of the DBConnection class
        public DBConnection()
        {
            connection = new SqlConnection(connectionString);
            command = new SqlCommand();
            command.Connection = connection;
        }
        //Static method which returns an object from DBConnection
        //To be used by the other form windows to manage data
        public static DBConnection getDBConnection()
        {
            return new DBConnection();
        }

        public int executeInsertUpdateQuery(string Query)
        {
            int count = 0;
            if (connection.State == ConnectionState.Closed)
            {
                connection.Open();
            }
            command.CommandText = Query;
            count = command.ExecuteNonQuery();
            connection.Close();
            return count;
        }

        public DataTable getDataTable(string selectCommand)
        {
            dataAdaptor = new SqlDataAdapter(selectCommand, connectionString);
            commandBuilder = new SqlCommandBuilder(dataAdaptor);
            DataTable table = new DataTable
            {
                Locale = CultureInfo.InvariantCulture
            };
            dataAdaptor.Fill(table);
            return table;
        }
    }
}
