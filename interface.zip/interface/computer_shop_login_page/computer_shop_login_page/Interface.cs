﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace computer_shop_login_page
{
    public partial class Interface : Form
    {
        public Interface()
        {
            InitializeComponent();
        }

        private void Interface_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }
        int startpos = 0;

        private void timer1_Tick(object sender, EventArgs e)
        {
            startpos += 1;
            progress.Value = startpos;
            Percentage_lb.Text = startpos + "%";
            if (progress.Value == 100)
            {
                progress.Value =0 ;
                timer1.Stop();


                Login login = new Login();
                login.Show();
                this.Hide();

            }
            
        }
        
        }
    }

    











    




   
